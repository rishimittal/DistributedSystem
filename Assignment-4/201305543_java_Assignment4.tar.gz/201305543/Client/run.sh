#!/bin/bash

javac *.java
java Client $1 $2 $3
