#!/bin/bash

javac *.java
java RegistryServer $1 $2
