#!/bin/bash

javac *.java
java FileServer $1 $2
