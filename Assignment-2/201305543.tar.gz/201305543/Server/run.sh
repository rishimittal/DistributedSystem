#!/bin/bash

javac *.java
java RMIServer $1
